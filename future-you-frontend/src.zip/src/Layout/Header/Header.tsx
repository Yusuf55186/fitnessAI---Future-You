import { Logo } from "../../components/ui/Logo/Logo";
import { Navigation } from "../Navigation";
import { LanguageSwitcher } from "../LanguageSwitcher";
import { Account } from "../Account";
import type { language } from "../../types/language";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LogoutUser } from "../../components/Logout";
type Props = {
    language: language;
    setLanguage: (language: language) => void;
    onLogout: () => Promise<void>;
};

export const Header = ({ language,setLanguage,onLogout}: Props) => {
    const navigate = useNavigate();
    const [username] = useState(
     () => localStorage.getItem('username') ?? ""
    );
    const NavigateToHome = () => {
        navigate('/')
    }
    return (
        <header
            className="
                sticky top-0 z-50
                flex h-fy-topbar w-full
                items-center justify-between
                border-b border-fy-border
                bg-fy-subtle/95
                px-fy-5
                backdrop-blur-md
            "
        >
            <div className="flex shrink-0 items-center">
                <Logo className="cursor-pointer hover:scale-105 translate-y-1 logo-transition ease-in" onClick={NavigateToHome} />
            </div>

            <nav className="hidden lg:flex items-center">
                <Navigation />
            </nav>

            <div className="flex items-center gap-fy-4">
                <LanguageSwitcher
                    language={language}
                    setLanguage={setLanguage}
                />

                <div className="h-7 w-px bg-fy-border" />
                <Link to={'/account'}>
                <Account username={username}   />
                </Link>
                <LogoutUser onLogout={onLogout} />
                
            </div>
        </header>
    );
}